import os, pandas as pd


df = pd.read_csv("../../../LDC/LDC2023E01_CCU_TA1_Mandarin_Chinese_Mini_Evaluation_Annotation_Unsequestered/index_files/AlignFile_tests.system_input.index.tab", sep="\t")
for idx, data in df.iterrows():
    fname = data["file_id"]+".tab"
    if not os.path.exists("predictions_103_trial/"+fname):
        this_ND = pd.DataFrame([], columns=["file_id","norm","start","end","status","llr"])
        this_ND.to_csv("predictions_103_trial/"+fname,sep="\t", index=False)

quit()
for fname in os.listdir("predictions_103_trial"):
    df = pd.read_csv("predictions_103_trial/"+fname, sep="\t")
    if ".tab" not in fname or "llr" not in df.columns:
        continue
    if df[df["llr"]<0].shape[0] > 0:
        print(fname)


